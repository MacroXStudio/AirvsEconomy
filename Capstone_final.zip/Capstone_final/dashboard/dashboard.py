import streamlit as st
import pandas as pd
import plotly.figure_factory as ff
import plotly.express as px
import streamlit.components.v1 as components

st.set_page_config(layout="wide", page_title="Emission_Eco Dashboard")

st.title("Emission to Eco Model Dashboard")

df = pd.read_csv('dependency/state_cities.csv')
cities_list = df[['CITY']].sort_values(by=['CITY'])

# initialize columns
col1, col2 = st.columns(2)

# Filters
with col1:
    choices = st.multiselect("Choose city", cities_list)
    gases = st.multiselect("Choose gases", ['PM2.5','SO2','NO2','CO'])
    ts_choice = st.radio("Apply time series for API pred?", ('Yes', 'No'), index=0)
    eco_model_choice = st.radio("Model for predicting Unemployment Rate", ("XGBoost", "Random Forest", "Elastic Net", "Linear Regression"))
    if eco_model_choice != "XGBoost":
        eco_model_choice = "_".join(eco_model_choice.split())



# map:
with col2:
    city_map = pd.read_csv('dependency/India_City_Coordinates.csv')
    city_map.columns = ['city','lat','lon']
    if len(choices)==0:
        all_cities = city_map.copy().iloc[:,1:]
        st.map(all_cities)
    else:
        selected_city = city_map[city_map['city'].isin(choices)]
        st.map(selected_city)

#container = st.columns(len(gases))

# get pred data from files

if ts_choice =='Yes':
    PM25_pred = pd.read_csv('../data/API Recreate/pred/csv/PM25_TS_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
    NO2_pred = pd.read_csv('../data/API Recreate/pred/csv/NO2_TS_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
    SO2_pred = pd.read_csv('../data/API Recreate/pred/csv/SO2_TS_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
    CO_pred = pd.read_csv('../data/API Recreate/pred/csv/CO_TS_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
else:
    PM25_pred = pd.read_csv('../data/API Recreate/pred/csv/PM25_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
    NO2_pred = pd.read_csv('../data/API Recreate/pred/csv/NO2_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
    SO2_pred = pd.read_csv('../data/API Recreate/pred/csv/SO2_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)
    CO_pred = pd.read_csv('../data/API Recreate/pred/csv/CO_pred.csv', parse_dates=["date"]).sort_values(by=['date']).reset_index(drop=True)

data_dict ={'PM2.5':PM25_pred, 'SO2':SO2_pred,'NO2':NO2_pred,'CO':CO_pred}

# Output info
if len(choices) == 0 or len(gases) == 0:
    st.info(
        f"""
            Select Cities and Gases First
            """
    )
else:
    # format data
    st.subheader("Emission Predictions")
    with st.expander("Gas Emission Prediction Results Here:", expanded = True):
        for gas in gases:  
            st.subheader(gas+ ' data for selected cities:')
            cur_df = data_dict[gas]
            city_names = ['date']
            col_names = ['Date']
            for choice in choices:
                if gas == 'PM2.5':
                    temp_choice = choice+'_PM25' 
                else: 
                    temp_choice = choice+'_'+gas
                if temp_choice not in cur_df.columns:
                    st.warning(f"{gas} for {choice} is not aviliable")
                    continue
                city_names.append(temp_choice)
                col_names.append(choice)
            
            cur_df = cur_df.loc[:,city_names]
            cur_df.columns = col_names
            cur_df = cur_df.sort_values("Date")

            # plot each gas
            if len(cur_df.columns)!=1:
                fig = px.line(cur_df, x="Date", y=cur_df.columns[1:])
                
                fig.update_layout(legend_title_text='City', legend={"orientation":"h"})
                st.plotly_chart(fig, use_container_width=True)
                #file_container = st.expander("View "+ gas+" raw data here:")
                #file_container.dataframe(cur_df, use_container_width=True, height=200)
                if st.checkbox("View raw data", key=gas+"_checkbox"):
                    cur_df["Date"] = cur_df["Date"].dt.date
                    cur_df = cur_df.set_index("Date")
                    st.dataframe(cur_df, use_container_width = True, height=200)

#Horizontal line

components.html("""<hr style="height:5px;border:none;color:#333;background-color:#333;" /> """)
st.subheader("Unemployment Rate")
           

if len(choices) == 0:
    st.info(
        f"""
            Select Cities First
            """
    )            
else:
    # read unemployment rate
    gt = st.checkbox("Display Ground Truth?")
    
    unemployment_pred_df = pd.DataFrame()
    for city in choices:
        try:
            t1 = pd.read_csv(f"../data/Predicted_unemployment_daily/{eco_model_choice}/{city}.csv", index_col=0, parse_dates=["Date"]).set_index("Date")
            if gt:
                unemployment_pred_df = unemployment_pred_df.join(t1[["Predicted_Unemployment_Rate", "ground_truth"]], how="outer")
                unemployment_pred_df = unemployment_pred_df.rename(columns={"Predicted_Unemployment_Rate":city+"_pred", "ground_truth":city+"_true"})
            else:
                unemployment_pred_df = unemployment_pred_df.join(t1["Predicted_Unemployment_Rate"], how="outer")
                unemployment_pred_df = unemployment_pred_df.rename(columns={"Predicted_Unemployment_Rate":city})
        except Exception as e:
            st.write(e)
            st.warning(f"Unemployment Rate for {city} is not aviliable")
    if len(unemployment_pred_df.columns):
        unemployment_pred_df = unemployment_pred_df.reset_index()

        # Output unemployment rate
        fig = px.line(unemployment_pred_df, x="Date", y=unemployment_pred_df.columns[1:])       
        fig.update_layout(legend_title_text='City', legend={"orientation":"h"}, yaxis_title = "Unemployment Rate %")
        

        st.plotly_chart(fig, use_container_width=True)


        # show raw data
        unemployment_pred_df["Date"] = unemployment_pred_df["Date"].dt.date
        unemployment_pred_df = unemployment_pred_df.set_index("Date")    
        file_container = st.expander("View raw data here:", expanded=False)
        file_container.dataframe(unemployment_pred_df, use_container_width=True, height=300)

